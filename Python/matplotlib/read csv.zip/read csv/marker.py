import numpy as np
import matplotlib.pyplot as plt

x=np.array([3,8,1,10])
plt.plot(x,marker='o')
plt.show()