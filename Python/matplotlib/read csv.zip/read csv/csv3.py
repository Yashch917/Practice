import numpy as np
import matplotlib.pyplot as plt

x=np.array([1,8])
y=np.array([3,10])
plt.plot(x,y)
plt.show()